package git;

import java.util.Scanner;

public class SumaNumeros {
	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		
		boolean validez = false;
		double valor1 = 0;
		
		while(!validez) {
			try {
				System.out.println("Digame el primer número que desea sumar:");
				valor1 = Double.parseDouble(scanner.nextLine());
				
				validez = true;
			}	
			catch (NumberFormatException e) {
				System.out.println("Error: Debe ser un número.");
			}
		}
		validez = false;
		
		while(!validez)
			try {
			System.out.println("Digame el segundo número que desea sumar:");
			double valor2 = Double.parseDouble(scanner.nextLine());
			
			double suma = valor1 + valor2;
			System.out.println("El valor total es: " + suma );

			validez = true;
			}
			catch (NumberFormatException e) {
				System.out.println("Error: Debe ser un número.");
			}
		scanner.close();
	}
}
